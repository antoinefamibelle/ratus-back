import express, { Request, Response, NextFunction } from 'express';
import axios from 'axios';
import dotenv from 'dotenv';
import serverless from 'serverless-http';
import { APIGatewayProxyEvent, APIGatewayProxyResult, Context } from 'aws-lambda';

// Load environment variables
dotenv.config();

const app = express();
const port = 3001;

// Types
interface TokenResponse {
    success: boolean;
    token?: string;
    data?: any;
    message: string;
    error?: string;
}

interface BankResponse {
    id: string;
    name: string;
    bic: string;
    transaction_total_days: string;
    countries: string[];
    logo: string;
    max_access_valid_for_days: string;
}

interface BankListResponse {
    success: boolean;
    data: BankResponse[];
    message: string;
    error?: string;
}

interface AgreementRequest {
    institution_id: string;
    max_historical_days: string;
    access_valid_for_days: string;
}

interface AgreementResponse {
    success: boolean;
    data: any;
    message: string;
    error?: string;
}

interface RequisitionRequest {
    redirect: string;
    institution_id: string;
    reference: string;
    agreement: string;
    user_language: string;
}

interface RequisitionDataResponse {
    id: string;
    redirect: string;
    status: {
        short: string;
        long: string;
        description: string;
    };
    agreement: string;
    accounts: any[];
    reference: string;
    user_language: string;
    link: string;
}

interface RequisitionResponse {
    success: boolean;
    data?: RequisitionDataResponse;
    message: string;
    error?: string;
}

interface RefreshTokenRequest {
    refresh: string;
}

// Middleware to parse JSON bodies
app.use(express.json());

app.get('/ping', (req: Request, res: Response) => res.send('pong'));

// Route for getting bank list
app.get('/bank/list', async (req: Request, res: Response<BankListResponse>) => {
    try {
        const response = await axios.get('https://bankaccountdata.gocardless.com/api/v2/institutions/', {
            params: {
                country: 'fr'
            },
            headers: {
                'Accept': 'application/json',
                'Authorization': `Bearer ${process.env.GOCARDLESS_ACCESS}`
            }
        });

        res.json({
            success: true,
            data: response.data,
            message: 'Banks list retrieved successfully'
        });
    } catch (error) {
        const err = error as Error;
        console.error(err);
        res.status(500).json({
            success: false,
            data: [],
            message: 'Error retrieving banks list',
            error: err.message
        });
    }
});

// Route for creating bank agreement
app.post('/bank/agreements', async (req: Request<{}, {}, AgreementRequest>, res: Response<AgreementResponse>) => {
    try {
        const { institution_id, max_historical_days, access_valid_for_days } = req.body;

        if (!institution_id || !max_historical_days || !access_valid_for_days) {
            return res.status(400).json({
                success: false,
                data: null,
                message: 'Missing required fields',
                error: 'All fields are required: institution_id, max_historical_days, access_valid_for_days'
            });
        }
        console.log('Institution ID:', institution_id);
        const response = await axios.post('https://bankaccountdata.gocardless.com/api/v2/agreements/enduser/', {
            institution_id,
            access_scope: ["balances", "details", "transactions"]
        }, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.GOCARDLESS_ACCESS}`
            }
        });

        res.json({
            success: true,
            data: response.data,
            message: 'Bank agreement created successfully'
        });
    } catch (error) {
        const err = error as Error;
        console.error(err);
        res.status(500).json({
            success: false,
            data: null,
            message: 'Error creating bank agreement',
            error: err.message
        });
    }
});

// Route for creating requisition
app.post('/bank/requisitions', async (req: Request<{}, {}, RequisitionRequest>, res: Response<RequisitionResponse>) => {
    try {
        const { institution_id, reference } = req.body;

        const user_language = 'fr'
        const redirect = 'https://antoinefamibelle.fr/ratus-success'

        if (!institution_id || !reference ) {
            return res.status(400).json({
                success: false,
                message: 'Missing required fields',
                error: 'All fields are required: institution_id, reference'
            });
        }

        console.log('Creating requisition for institution:', institution_id);
        const response = await axios.post('https://bankaccountdata.gocardless.com/api/v2/requisitions/', {
            redirect,
            institution_id,
            reference,
            user_language
        }, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${process.env.GOCARDLESS_ACCESS}`
            }
        });

        res.json({
            success: true,
            data: response.data,
            message: 'Requisition created successfully'
        });
    } catch (error) {
        const err = error as Error;
        console.error(err);
        res.status(500).json({
            success: false,
            message: 'Error creating requisition',
            error: err.message
        });
    }
});

// Route for generating new token
app.post('/bank/token/new', async (req: Request, res: Response<TokenResponse>) => {
    try {
        const response = await axios.post('https://bankaccountdata.gocardless.com/api/v2/token/new/', {
            secret_id: process.env.GOCARDLESS_SECRET_ID,
            secret_key: process.env.GOCARDLESS_SECRET_KEY
        }, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });

        res.json({
            success: true,
            data: response.data,
            token: response.data.access,
            message: 'New token generated successfully'
        });
    } catch (error) {
        const err = error as Error;
        console.error(err);
        res.status(500).json({
            success: false,
            message: 'Error generating token',
            error: err.message
        });
    }
});

// Route for refreshing token
app.post('/bank/token/refresh', async (req: Request<{}, {}, RefreshTokenRequest>, res: Response<TokenResponse>) => {
    try {
        const { refresh } = req.body;
        
        if (!refresh) {
            return res.status(400).json({
                success: false,
                message: 'Refresh token is required'
            });
        }

        const response = await axios.post('https://bankaccountdata.gocardless.com/api/v2/token/refresh/', {
            refresh
        }, {
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            }
        });

        res.json({
            success: true,
            data: response.data,
            token: response.data.access,
            message: 'Token refreshed successfully'
        });
    } catch (error) {
        const err = error as Error;
        console.error(err);
        res.status(500).json({
            success: false,
            message: 'Error refreshing token',
            error: err.message
        });
    }
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response<TokenResponse>, next: NextFunction) => {
    console.error(err.stack);
    res.status(500).json({
        success: false,
        message: 'Something went wrong!',
        error: err.message
    });
});

// Create the handler function
const serverlessHandler = serverless(app);

// Export the Lambda handler
export const handler = serverlessHandler;
